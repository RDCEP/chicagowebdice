$(document).ready(function() {
	
	chart1 = new Highcharts.Chart({
		chart: {
		    renderTo:'chart1',
		    zoomType:'x',
		},
		title: {
		    text: 'Global Emissions'
		},
		xAxis:{
		    type: 'datetime',
		    maxZoom: 5 * 10 * 365 * 24 * 3600000 // 50 years
		},
		yAxis:{
		    title:{
			text: 'Carbon Emitted'
		    },
		    min: 0,
		    startOnTick:false,
		    showFirstLabe:false
		},
		tooltip:{
		    shared:true
		},
		series:[{
			type: 'area',
			name: 'Global Emissions 1',
			pointInterval: 10 * 365 * 24 * 3600000,
			pointStart: Date.UTC(2005,0,01),
			data: [
			       0.0857,
			       0.0955,
			       0.1060,
			       0.1169,
			       0.1281,
			       0.1395,
			       0.1512,
			       0.1634,
			       0.1762,
			       0.1897,
			       0.2041,
			       0.2194,
			       0.2357,
			       0.2533,
			       0.2721,
			       0.2923,
			       0.3139,
			       0.3372,
			       0.3622,
			       0.3891,
			       0.4178,
			       0.4487,
			       0.4818,
			       0.5172,
			       0.5551
			       ]
			
		    },	{
			type: 'area',
			name: 'Global Emissions 2',
			pointInterval: 10 * 365 * 24 * 3600000,
			pointStart: Date.UTC(2005,0,01),
			data: [
			       0.0428,
			       0.0477,
			       0.0530,
			       0.0585,
			       0.0640,
			       0.0697,
			       0.0756,
			       0.0817,
			       0.0881,
			       0.0949,
			       0.1020,
			       0.1097,
			       0.1179,
			       0.1266,
			       0.1360,
			       0.1461,
			       0.1570,
			       0.1686,
			       0.1811,
			       0.1945,
			       0.2089,
			       0.2243,
			       0.2409,
			       0.2586,
			       0.2776,
			       ]

		    }]
		    });

	chart2 = new Highcharts.Chart({
		chart: {
		    renderTo:'chart2',
		    zoomType:'x',
		},
		title: {
		    text: 'Carbon Dioxide Concentration'
		},
		xAxis:{
		    type: 'datetime',
		    maxZoom: 5 * 10 * 365 * 24 * 3600000 // 50 years
		},
		yAxis:{
		    title:{
			text: 'Carbon (ppm)'
		    },
		    min: 0,
		    startOnTick:false,
		    showFirstLabe:false
		},
		tooltip:{
		    shared:true
		},
		series:[{
			type: 'area',
			name: 'CO2 Concentration 1',
			pointInterval: 10 * 365 * 24 * 3600000,
			pointStart: Date.UTC(2005,0,01),
			data: [
			       0.0857,
			       0.0955,
			       0.1060,
			       0.1169,
			       0.1281,
			       0.1395,
			       0.1512,
			       0.1634,
			       0.1762,
			       0.1897,
			       0.2041,
			       0.2194,
			       0.2357,
			       0.2533,
			       0.2721,
			       0.2923,
			       0.3139,
			       0.3372,
			       0.3622,
			       0.3891,
			       0.4178,
			       0.4487,
			       0.4818,
			       0.5172,
			       0.5551
			       ]
			
		    },	{
			type: 'area',
			name: 'CO2 Concentration 2',
			pointInterval: 10 * 365 * 24 * 3600000,
			pointStart: Date.UTC(2005,0,01),
			data: [
			       0.0428,
			       0.0477,
			       0.0530,
			       0.0585,
			       0.0640,
			       0.0697,
			       0.0756,
			       0.0817,
			       0.0881,
			       0.0949,
			       0.1020,
			       0.1097,
			       0.1179,
			       0.1266,
			       0.1360,
			       0.1461,
			       0.1570,
			       0.1686,
			       0.1811,
			       0.1945,
			       0.2089,
			       0.2243,
			       0.2409,
			       0.2586,
			       0.2776,
			       ]

		    }]
		    });
		    
	chart3 = new Highcharts.Chart({
		chart: {
		    renderTo:'chart3',
		    zoomType:'x',
		},
		title: {
		    text: 'Global Temperature'
		},
		xAxis:{
		    type: 'datetime',
		    maxZoom: 5 * 10 * 365 * 24 * 3600000 // 50 years
		},
		yAxis:{
		    title:{
			text: 'Degrees Celsius'
		    },
		    min: 0,
		    startOnTick:false,
		    showFirstLabe:false
		},
		tooltip:{
		    shared:true
		},
		series:[{
			type: 'area',
			name: 'Global Temp 1',
			pointInterval: 10 * 365 * 24 * 3600000,
			pointStart: Date.UTC(2005,0,01),
			data: [
			       0.0857,
			       0.0955,
			       0.1060,
			       0.1169,
			       0.1281,
			       0.1395,
			       0.1512,
			       0.1634,
			       0.1762,
			       0.1897,
			       0.2041,
			       0.2194,
			       0.2357,
			       0.2533,
			       0.2721,
			       0.2923,
			       0.3139,
			       0.3372,
			       0.3622,
			       0.3891,
			       0.4178,
			       0.4487,
			       0.4818,
			       0.5172,
			       0.5551
			       ]
			
		    },	{
			type: 'area',
			name: 'Global Temp 2',
			pointInterval: 10 * 365 * 24 * 3600000,
			pointStart: Date.UTC(2005,0,01),
			data: [
			       0.0428,
			       0.0477,
			       0.0530,
			       0.0585,
			       0.0640,
			       0.0697,
			       0.0756,
			       0.0817,
			       0.0881,
			       0.0949,
			       0.1020,
			       0.1097,
			       0.1179,
			       0.1266,
			       0.1360,
			       0.1461,
			       0.1570,
			       0.1686,
			       0.1811,
			       0.1945,
			       0.2089,
			       0.2243,
			       0.2409,
			       0.2586,
			       0.2776,
			       ]

		    }]
		    });
	
	var options = {
	    chart: {
		renderTo:'chart4',
		zoomType:'x',
	    },
	    title: {
		text: 'Per Capita Consumption'
	    },
	    xAxis: {
		type: 'datetime',
		maxZoom: 5 * 10 * 365 * 24 * 3600000
	    },
	    yAxis: {
		title:{
		    text: 'Dollars per Person'
		},
		min: 0,
		startOnTick:false,
		showFirstLabel:false
	    },
	    tooltip: {
		shared:true
	    },
	    series: []
	};

	$.get('data/pcc.csv', function(data) {
		// Split lines
		var lines = data.split('\n');

		// Iterate over lines and add series
		$.each(lines, function(lineNo, line) {
			var items = line.split(',');

			// header has title text
			if (lineNo == 0) {
			    $.each(items,function(itemNo, item) {
				    options.title.text = item;
				});
			}
			
			// other lines have data for series
			else{
			    var series = {
				type: 'area',
				pointInterval: 10 * 365 * 24 * 3600000,
				pointStart: Date.UTC(2005,0,01),
				data: []
			    };
			    $.each(items, function(itemNo, item) {
				    if (itemNo == 0) {
					series.name = item;
				    } else {
					series.data.push(parseFloat(item));
				    }
				});
			    options.series.push(series);
			}
		    });

		// Create the chart
		var chart = new Highcharts.Chart(options);
					
	    });
	/*
	chart4 = new Highcharts.Chart({
		chart: {
		    renderTo:'chart4',
		    zoomType:'x',
		},
		title: {
		    text: 'Per Capita Consumption'
		},
		xAxis:{
		    type: 'datetime',
		    maxZoom: 5 * 10 * 365 * 24 * 3600000 // 50 years
		},
		yAxis:{
		    title:{
			text: 'Dollars ($) per Person'
		    },
		    min: 0,
		    startOnTick:false,
		    showFirstLabel:false
		},
		tooltip:{
		    shared:true
		},
		series:[{
			type: 'area',
			name: 'Per Capita Consumption 1',
			pointInterval: 10 * 365 * 24 * 3600000,
			pointStart: Date.UTC(2005,0,01),
			data: [
			       0.0857,
			       0.0955,
			       0.1060,
			       0.1169,
			       0.1281,
			       0.1395,
			       0.1512,
			       0.1634,
			       0.1762,
			       0.1897,
			       0.2041,
			       0.2194,
			       0.2357,
			       0.2533,
			       0.2721,
			       0.2923,
			       0.3139,
			       0.3372,
			       0.3622,
			       0.3891,
			       0.4178,
			       0.4487,
			       0.4818,
			       0.5172,
			       0.5551
			       ]
			
		    },	{
			type: 'area',
			name: 'Per Capita Consumption 2',
			pointInterval: 10 * 365 * 24 * 3600000,
			pointStart: Date.UTC(2005,0,01),
			data: [
			       0.0428,
			       0.0477,
			       0.0530,
			       0.0585,
			       0.0640,
			       0.0697,
			       0.0756,
			       0.0817,
			       0.0881,
			       0.0949,
			       0.1020,
			       0.1097,
			       0.1179,
			       0.1266,
			       0.1360,
			       0.1461,
			       0.1570,
			       0.1686,
			       0.1811,
			       0.1945,
			       0.2089,
			       0.2243,
			       0.2409,
			       0.2586,
			       0.2776,
			       ]

		    }]
		    });
	*/
    });

function simulationDICE(){
    var options = {
	chart: {
	    renderTo:'chart4',
	    zoomType:'x',
	},
	title: {
	    text: 'Per Capita Consumption'
	},
	xAxis: {
	    type: 'datetime',
	    maxZoom: 5 * 10 * 365 * 24 * 3600000
	},
	yAxis: {
	    title:{
		text: 'Dollars per Person'
	    },
	    min: 0,
	    startOnTick:false,
	    showFirstLabel:false
	},
	tooltip: {
	    shared:true
	},
	series: []
    };
    
    $.get('data/pcc.csv', function(data) {
	    // Split lines
	    var lines = data.split('\n');
	    
	    // Iterate over lines and add series
	    $.each(lines, function(lineNo, line) {
		    var items = line.split(',');
		    
		    // header has title text
		    if (lineNo == 0) {
			$.each(items,function(itemNo, item) {
				options.title.text = item;
			    });
		    }
		    
		    // other lines have data for series
		    else{
			var series = {
			    type: 'area',
			    pointInterval: 10 * 365 * 24 * 3600000,
			    pointStart: Date.UTC(2005,0,01),
			    data: []
			};
			$.each(items, function(itemNo, item) {
				if (itemNo == 0) {
				    series.name = item;
				} else {
				    series.data.push(parseFloat(item));
				}
			    });
			options.series.push(series);
		    }
		});
	    
	    // Create the chart
	    var chart = new Highcharts.Chart(options);
	    
	});
    alert("DICE computations completed!");
}