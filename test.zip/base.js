$(document).ready(function() {


	// Tabs
	$("#inputTabs").tabs();
	$("#outputTabs").tabs();

    });