$(document).ready(function() {

	// Accordion
	$("#accordion1").accordion({
		autoHeight:false,
		    });
	$("#accordion2").accordion({
		autoHeight:false
		    });
	      
	// Sliders
	// Parameters
	$("#slider1").slider({
		value:2,
		    min:1,
		    max:3,
		    step:.25,
		    slide: function( event, ui ) {
		    $( "#climateSensitivity" ).val(ui.value );
		    }
	    });
	$("#climateSensitivity").val($("#slider1").slider("value"));

	$("#slider2").slider({
		value:2,
		    min:1,
		    max:3,
		    step:.25,
		    slide: function( event, ui ) {
		    $( "#damages" ).val(ui.value );
		    }
	    });
	$("#damages").val($("#slider2").slider("value"));

	$("#slider3").slider({
		value:2,
		    min:1,
		    max:3,
		    step:.25,
		    slide: function( event, ui ) {
		    $( "#popGrowth" ).val(ui.value );
		    }
	    });
	$("#popGrowth").val($("#slider3").slider("value"));

	$("#slider4").slider({
		value:2,
		    min:1,
		    max:3,
		    step:.25,
		    slide: function( event, ui ) {
		    $( "#techGrowth" ).val(ui.value );
		    }
	    });
	$("#techGrowth").val($("#slider4").slider("value"));

	// Carbon Abatement Strategy
	$("#slider5").slider({
		value:0,
		    min:0,
		    max:100,
		    step:5,
		    slide: function( event, ui ) {
		    $( "#abate2050" ).val(ui.value + "%" );
		    }
	    });
	$(".abate2050").val($("#slider5").slider("value") + "%");

	$("#slider6").slider({
		value:0,
		    min:0,
		    max:100,
		    step:5,
		    slide: function( event, ui ) {
		    $( "#abate2100" ).val(ui.value + "%" );
		    }
	    });
	$("#abate2100").val($("#slider6").slider("value") + "%");

	$("#slider7").slider({
		value:0,
		    min:0,
		    max:100,
		    step:5,
		    slide: function( event, ui ) {
		    $( "#abate2150" ).val(ui.value + "%" );
		    }
	    });
	$("#abate2150").val($("#slider7").slider("value") + "%");

	// Submit Buttons

	$("input:submit").button();

    });