#(document).ready()function() {
    
    // Accordion
    $("#accordion6").accordion({
	    autoHeight:false
		});

    // Buttons
    $("#radioCarbon1").buttonset();
    $("#radioDamage1").buttonset();

		  });